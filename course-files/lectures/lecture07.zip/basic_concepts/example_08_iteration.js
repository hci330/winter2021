const names = ['charlie', 'freddie', 'lucy'];
for (name of names) {
    console.log(name.toUpperCase());
}