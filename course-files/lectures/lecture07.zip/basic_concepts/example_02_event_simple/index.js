const add_numbers = () => {
    //your code here...
    alert("Calculate the sum");
}

document.getElementById('add_button').onclick = add_numbers;