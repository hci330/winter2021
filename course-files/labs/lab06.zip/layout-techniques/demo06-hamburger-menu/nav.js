document.querySelector('#menu-button').onclick = (ev) => {
    document.querySelector('nav').classList.toggle('mobile-view');
};